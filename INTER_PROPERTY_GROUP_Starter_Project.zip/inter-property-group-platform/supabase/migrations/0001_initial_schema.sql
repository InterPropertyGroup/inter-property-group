-- INTER PROPERTY GROUP: international, multi-agency foundation
-- Apply in a new Supabase project after reviewing this migration.
create extension if not exists pgcrypto;

create table if not exists public.organisations (
  id uuid primary key default gen_random_uuid(),
  legal_name text not null,
  display_name text not null,
  company_number text,
  country_code char(2) not null default 'GB',
  default_currency char(3) not null default 'GBP',
  default_locale text not null default 'en-GB',
  timezone text not null default 'Europe/London',
  created_at timestamptz not null default now()
);

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','manager','finance','staff','viewer')),
  created_at timestamptz not null default now(),
  unique (organisation_id,user_id)
);

create index if not exists memberships_user_idx on public.memberships(user_id);
create index if not exists memberships_org_idx on public.memberships(organisation_id);

-- Returns true only where the signed-in user is a member of the organisation.
create or replace function public.is_org_member(target_org uuid)
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.memberships m
    where m.organisation_id = target_org and m.user_id = auth.uid()
  );
$$;

-- Resolve the user's active organisation only when exactly one membership exists.
-- Multi-organisation switching will be added as an explicit workspace selector.
create or replace function public.current_organisation_id()
returns uuid language sql stable security definer
set search_path = public
as $$
  select organisation_id from public.memberships
  where user_id = auth.uid()
  order by created_at asc
  limit 1;
$$;


create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null default public.current_organisation_id()
    references public.organisations(id) on delete cascade,
  name text not null,
  property_type text not null default 'residential'
    check (property_type in ('holiday_rental','residential','commercial','investment','other')),
  status text not null default 'draft'
    check (status in ('draft','active','managed','paused','archived')),
  address_line_1 text,
  address_line_2 text,
  city text,
  region text,
  postal_code text,
  country_code char(2) not null,
  currency_code char(3) not null,
  timezone text,
  description text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists properties_org_idx on public.properties(organisation_id);
create index if not exists properties_country_idx on public.properties(country_code);

alter table public.organisations enable row level security;
alter table public.memberships enable row level security;
alter table public.properties enable row level security;

create policy "Members can view their organisations"
on public.organisations for select
using (public.is_org_member(id));

create policy "Members can view memberships in their organisations"
on public.memberships for select
using (public.is_org_member(organisation_id));

create policy "Members can view properties in their organisations"
on public.properties for select
using (public.is_org_member(organisation_id));

create policy "Authorised members can create properties"
on public.properties for insert
with check (
  public.is_org_member(organisation_id)
  and exists (
    select 1 from public.memberships m
    where m.organisation_id = organisation_id
      and m.user_id = auth.uid()
      and m.role in ('owner','admin','manager','staff')
  )
);

create policy "Authorised members can update properties"
on public.properties for update
using (
  public.is_org_member(organisation_id)
  and exists (
    select 1 from public.memberships m
    where m.organisation_id = organisation_id
      and m.user_id = auth.uid()
      and m.role in ('owner','admin','manager')
  )
)
with check (public.is_org_member(organisation_id));

create policy "Admins can delete properties"
on public.properties for delete
using (
  exists (
    select 1 from public.memberships m
    where m.organisation_id = organisation_id
      and m.user_id = auth.uid()
      and m.role in ('owner','admin')
  )
);

-- Note: bootstrap organisation and first owner membership through a trusted
-- server-side onboarding function after auth signup. Never expose service-role keys.
