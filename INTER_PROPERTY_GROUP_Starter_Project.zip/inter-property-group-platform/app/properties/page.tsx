 "use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase";

type Property = { id:string; name:string; city:string|null; country_code:string; property_type:string; status:string; currency_code:string };
export default function PropertiesPage() {
  const [items,setItems] = useState<Property[]>([]);
  const [loading,setLoading] = useState(true);
  const [error,setError] = useState("");
  const [name,setName] = useState("");
  const [city,setCity] = useState("");
  const [country,setCountry] = useState("ES");
  const [type,setType] = useState("holiday_rental");
  const [currency,setCurrency] = useState("EUR");
  const [saving,setSaving] = useState(false);
  const [ready,setReady] = useState(false);

  useEffect(()=>{ try { createClient(); setReady(true); } catch { setError("Connect Supabase by adding the environment variables in .env.local and applying the database migration."); setLoading(false); } },[]);
  async function load() {
    try {
      const supabase = createClient();
      const {data,error} = await supabase.from("properties").select("id,name,city,country_code,property_type,status,currency_code").order("created_at",{ascending:false});
      if(error) throw error;
      setItems(data ?? []);
    } catch(e) { setError(e instanceof Error ? e.message : "Unable to load properties."); }
    finally { setLoading(false); }
  }
  useEffect(()=>{ if(ready) void load(); },[ready]);
  async function addProperty(e:React.FormEvent) {
    e.preventDefault(); setSaving(true); setError("");
    try {
      const supabase = createClient();
      const {error} = await supabase.from("properties").insert({
        name, city:city || null, country_code:country.toUpperCase(),
        property_type:type, currency_code:currency.toUpperCase(), status:"draft"
      });
      if(error) throw error;
      setName(""); setCity(""); await load();
    } catch(e) { setError(e instanceof Error ? e.message : "Could not save property."); }
    finally { setSaving(false); }
  }
  return <div className="shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark">⌂</div><div className="brand-name">INTER <span>PROPERTY</span><br/>GROUP</div></div><nav className="nav"><Link href="/">Overview</Link><Link className="active" href="/properties">Properties</Link><Link href="#">Owners</Link><Link href="#">Bookings</Link><Link href="#">Maintenance</Link><Link href="#">Inspections</Link><Link href="#">Finance</Link><Link href="#">Settings</Link></nav><div className="sidebar-foot">INTER PROPERTY GROUP LIMITED<br/>Company No. 16816787</div></aside>
    <main className="main"><header className="topbar"><div><strong>Property portfolio</strong><br/><small>Central property register</small></div><Link href="/" style={{color:"#777",fontSize:13}}>← Dashboard</Link></header>
      <div className="content"><div className="eyebrow">Portfolio management</div><h1>Properties</h1><p className="subtitle">Create and manage property records across countries and currencies.</p>
        <div className="card"><h2 style={{fontSize:18,marginTop:0}}>Add a property</h2>
          <form onSubmit={addProperty} className="form-row">
            <input className="input" required placeholder="Property name" value={name} onChange={e=>setName(e.target.value)}/>
            <input className="input" placeholder="City / region" value={city} onChange={e=>setCity(e.target.value)}/>
            <input className="input" required maxLength={2} placeholder="Country code (e.g. ES)" value={country} onChange={e=>setCountry(e.target.value)}/>
            <select className="input" value={type} onChange={e=>setType(e.target.value)}><option value="holiday_rental">Holiday rental</option><option value="residential">Residential</option><option value="commercial">Commercial</option><option value="investment">Investment</option><option value="other">Other</option></select>
            <select className="input" value={currency} onChange={e=>setCurrency(e.target.value)}><option>EUR</option><option>GBP</option><option>USD</option><option>CAD</option><option>AUD</option><option>CHF</option></select>
            <button className="btn gold" disabled={saving}>{saving?"Saving…":"Save property"}</button>
          </form>
          <p className="metric-note">New records are created as drafts. Country-specific compliance and tax requirements are configured separately.</p>
        </div>
        {error && <div className="card" style={{marginTop:16,color:"#9b3c2f"}}>{error}</div>}
        <div className="section-head"><h2>Property records</h2><span className="metric-note">{items.length} records</span></div>
        <div className="table-wrap"><table><thead><tr><th>Property</th><th>Location</th><th>Type</th><th>Currency</th><th>Status</th></tr></thead><tbody>
          {loading?<tr><td colSpan={5}>Loading properties…</td></tr>:items.length===0?<tr><td colSpan={5} className="empty">No properties saved yet. Add your first property above.</td></tr>:items.map(p=><tr key={p.id}><td><strong>{p.name}</strong></td><td>{p.city?`${p.city}, `:""}{p.country_code}</td><td>{p.property_type.replace("_"," ")}</td><td>{p.currency_code}</td><td><span className="status">{p.status}</span></td></tr>)}
        </tbody></table></div>
      </div>
    </main>
  </div>;
}