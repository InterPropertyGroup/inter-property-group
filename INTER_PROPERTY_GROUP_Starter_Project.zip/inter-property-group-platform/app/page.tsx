import Link from "next/link";

const nav = [
  ["Overview","/"],["Properties","/properties"],["Owners","#"],["Bookings","#"],
  ["Maintenance","#"],["Inspections","#"],["Finance","#"],["CRM","#"],["Reports","#"],["Settings","#"]
];
export default function Home() {
  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">⌂</div><div className="brand-name">INTER <span>PROPERTY</span><br/>GROUP</div></div>
      <div><div className="eyebrow" style={{padding:"0 12px 10px"}}>Workspace</div><nav className="nav">{nav.map(([label,href],i)=><Link className={i===0?"active":""} key={label} href={href}>{label}</Link>)}</nav></div>
      <div className="sidebar-foot">INTER PROPERTY GROUP LIMITED<br/>Company No. 16816787<br/><br/>International property management</div>
    </aside>
    <main className="main">
      <header className="topbar"><div><strong>Agency workspace</strong><br/><small>INTER PROPERTY GROUP LIMITED</small></div><small>Global platform · English (UK)</small></header>
      <div className="content">
        <div className="eyebrow">Agency overview</div><h1>Good morning.</h1><p className="subtitle">Your property operations, brought together.</p>
        <section className="grid">
          {[
            ["Properties","0","Add your first property"],
            ["Owners","0","Owner records"],
            ["Bookings","0","Reservations"],
            ["Open maintenance","0","Jobs requiring attention"]
          ].map(([label,value,note])=><div className="card" key={label}><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-note">{note}</div></div>)}
        </section>
        <div className="section-head"><h2>Get started</h2><Link href="/properties"><button className="btn gold">Open property portfolio →</button></Link></div>
        <div className="card" style={{padding:0}}>
          <div style={{padding:20,borderBottom:"1px solid #eee"}}><strong>Build your property portfolio</strong><p className="metric-note">Create the central property records that owners, bookings, maintenance, inspections and finance will connect to.</p></div>
          <div className="empty">No live property records yet. Start by adding a property.</div>
        </div>
        <div className="section-head"><h2>Platform modules</h2></div>
        <section className="grid">
          {["Property management","Owner portal","Bookings & calendar","Maintenance","Inspections","Finance & reporting","CRM","International settings"].map(x=><div className="card" key={x}><strong style={{fontSize:13}}>{x}</strong><div className="metric-note">Planned module</div></div>)}
        </section>
      </div>
    </main>
  </div>;
}