import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "INTER PROPERTY GROUP | Property Management",
  description: "International property management platform by INTER PROPERTY GROUP LIMITED."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}